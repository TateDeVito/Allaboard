
public class Equipment{
	//gps location - will inherit location from rider
	String brand;
	String name;
	double rentPrice;
	int type; //will produce what type of equip it is - snowboard, skis, or surf board
	//this will be derived
	//measurements will be different for every type of equipment

	public Equipment(String brand, String name, double rent){
		this.brand = brand;
		this.name = name;
		this.rentPrice = rent;
	}
	
	public String getInfo(){
		return brand + " " + name;
		}
	
	
	public static void main(String[] args){
		Equipment mySBoard = new Equipment("Never Summer", "Proto Type II", 30);
		
		System.out.println(mySBoard.getInfo());
		
		return;
		}
}
